const express= require("express");

const app =express();


 const logger= function(req,res,next)
{
    res.send(req.path);
    next();
}

app.use(logger);

const checkPermission= function(req,res,next){

       if(req.path=="/libraries")
       {
           res.send({route:req.path, permission:true})
       }
       else if(req.path =="/authors")
       {
           res.send({route:req.path, permission:true})
       }
}
app.use(checkPermission)



app.get("/books",function(req,res){

    return res.send({ route: "/books"})
})
app.get("/libraries",function(req,res){

    return res.send({ route: "/libraries", permission: true})
})
app.get("/authors ",function(req,res){

    return res.send({ route: "/authors", permission: true})
})



app.listen(2555,()=>{

    console.log("Listening on port 2555");
})

